package com.example.dell.recyclerview;

import com.example.dell.recyclerview.Country;
import com.example.dell.recyclerview.R;

import java.util.ArrayList;
import java.util.List;

public class CountryDao {
    private static List <Country> countries = new ArrayList<>();
    static {
        Country country1 = new Country("India","Delhi",R.drawable.india," Country with unity in differences","Narendra Modi");
        Country country2 = new Country("USA","Washington",R.drawable.usa,"Country having super power","Trump");
        Country country3 = new Country("Germany","Berlin",R.drawable.germany,"Country having largest industries","Markel");
        Country country4 = new Country("Pak","Islamabad",R.drawable.pak," Country having most terrible","Sharif");
        Country country5 = new Country("Bangladesh","Dhaka",R.drawable.bangladesh," A Country of southern Asia on the bay of bengal ","Sheikh Hasina");
        Country country6 = new Country("Nepal","katmandu",R.drawable.nepal,"Landlocked country in south asia","Prema khandu");
        Country country7 = new Country("Bhutan","Thimphu",R.drawable.bhutan,"Country with unity in differences","Tshering Tobgay");
        Country country8 = new Country("England","London",R.drawable.england,"Country with unity in differences","Theresasa may");
        Country country9 = new Country("Africa","Pretoria",R.drawable.africa,"Country with unity in differences","Louis Botha");
        Country country10 = new Country("Syria","Damascus",R.drawable.syria,"Country with unity in differences","Imad Khamis");
        countries.add(country1);
        countries.add(country2);
        countries.add(country3);
        countries.add(country4);
        countries.add(country5);
        countries.add(country6);
        countries.add(country7);
        countries.add(country8);
        countries.add(country9);
        countries.add(country10);
    }


    public static List<Country> getCountries(){

        return countries;
    }
  public static Country getCountry (int position){
        return countries.get(position);
  }

}
