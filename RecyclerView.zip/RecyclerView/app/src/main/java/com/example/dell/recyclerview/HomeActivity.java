package com.example.dell.recyclerview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class HomeActivity extends AppCompatActivity {

   TextView textView;
   TextView textView1;
   TextView textView2;
    TextView textView3;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        textView = findViewById(R.id.textView6);
        textView1 = findViewById(R.id.textView7);
        textView2 = findViewById(R.id.textView8);
        textView3 = findViewById(R.id.textView9);
        imageView = findViewById(R.id.imageView);


        int position = getIntent().getIntExtra("position",0);
         textView.setText(position +"");

         Country country = new  CountryDBDao(this).getCountry((position));
         textView.setText(country.name);//null pointer exception due to null.name call
        textView1.setText(country.capitalName);
        textView2.setText(country.description);
        textView3.setText(country.primeMinisterName);
        imageView.setImageResource(country.flag);
    }

}
