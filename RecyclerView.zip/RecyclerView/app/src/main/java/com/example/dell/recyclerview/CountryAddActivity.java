package com.example.dell.recyclerview;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class CountryAddActivity extends AppCompatActivity {
  EditText textView1;
    EditText textView4;
    EditText textView2;
    EditText textView3;
    ImageView imageView;
    String name,capital,pm,desc;
    int flag;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_country_add);
        textView1 = findViewById(R.id.editText);
        textView2 = findViewById(R.id.editText2);
        textView3 = findViewById(R.id.editText3);
        textView4 = findViewById(R.id.editText4);
        imageView=findViewById(R.id.imageView3);
      Button  button = (Button) findViewById(R.id.button2);
        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                try{
                    name = textView1.getText().toString();
                   capital = textView2.getText().toString();
                    pm= textView3.getText().toString();
                    desc = textView4.getText().toString();
                    Country country=new Country(name,capital,R.drawable.india,pm,desc);

                    new CountryDBDao(getApplicationContext()).insertCountry(country);

                    Toast.makeText(getApplicationContext(),"Country submitted successfully.",Toast.LENGTH_SHORT).show();
                    Intent MainActivity = new Intent(getApplicationContext(), com.example.dell.recyclerview.MainActivity.class);
                    startActivity(MainActivity);
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(),"Country submissio failed. Please try again after some time.",Toast.LENGTH_SHORT).show();
                }

            }
        });

    }
}
