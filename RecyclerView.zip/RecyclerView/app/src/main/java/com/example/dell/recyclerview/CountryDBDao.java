package com.example.dell.recyclerview;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.dell.recyclerview.Country;

import java.util.ArrayList;
import java.util.List;

import static android.content.ContentValues.TAG;
import static android.content.Context.MODE_PRIVATE;


public class CountryDBDao {
    private List <Country> countries = new ArrayList <>();
    private SQLiteDatabase myDatabase;
    private Context context;

    CountryDBDao(Context context) {
        this.context = context;
        initializeData();
       if (checkIfcountryTableIsEmpty()) {
           insert();
       }
    }



   /* static  {
        initializeData();
    }*/

    // private static void initializeData() {
    // }
    public void insert() {
        myDatabase.execSQL("INSERT INTO countries(name,capitalName,flag,primeMinisterName,description) values('India','Delhi'," + R.drawable.india + ",'Narendra Modi','Country with unity in differences')");
        myDatabase.execSQL("INSERT INTO countries(name,capitalName,flag,primeMinisterName,description) values('USA','Washington'," + R.drawable.usa + ",'Trump','Country having more power')");
        myDatabase.execSQL("INSERT INTO countries(name,capitalName,flag,primeMinisterName,description) values('Germany','Berlin'," + R.drawable.germany + ",'Markel','Country having largest industries')");
        myDatabase.execSQL("INSERT INTO countries(name,capitalName,flag,primeMinisterName,description) values('Pak','Islamabad'," + R.drawable.pak + ",'Sharif','Country having most terrible')");
        myDatabase.execSQL("INSERT INTO countries(name,capitalName,flag,primeMinisterName,description) values('Bangladesh','Dhaka'," + R.drawable.bangladesh + ",'Sheikh Hasina','A country of southern Asia on the')");
        myDatabase.execSQL("INSERT INTO countries(name,capitalName,flag,primeMinisterName,description) values('Nepal','Katmandu'," + R.drawable.nepal + ",'Prema Khandu','Landlocked country in south asia')");
        myDatabase.execSQL("INSERT INTO countries(name,capitalName,flag,primeMinisterName,description) values('Bhutan','Thimphu'," + R.drawable.bhutan + ",'Tshering Tobgay','Country with unity in differences')");
        myDatabase.execSQL("INSERT INTO countries(name,capitalName,flag,primeMinisterName,description) values('England','London'," + R.drawable.england + ",'Theresasamay','Country with unity in differences')");
        myDatabase.execSQL("INSERT INTO countries(name,capitalName,flag,primeMinisterName,description) values('Africa','Pretoria'," + R.drawable.africa + ",'Louis Botha','Country with unity in differences')");
        myDatabase.execSQL("INSERT INTO countries(name,capitalName,flag,primeMinisterName,description) values('Syria','Damascus'," + R.drawable.syria + ",'Imad khamish','Country with unitynin differences')");
    }

    public void initializeData() {
        myDatabase = context.openOrCreateDatabase("SQLite Demo", MODE_PRIVATE, null);
        myDatabase.execSQL("CREATE TABLE IF NOT EXISTS countries(position INTEGER PRIMARY KEY AUTOINCREMENT,name VARCHAR, capitalName VARCHAR, flag INT(10),primeMinisterName VARCHAR, description VARCHAR)");
      // myDatabase.execSQL("DELETE FROM countries");
    }

    public List <Country> getCountries() {
        Cursor cursor = myDatabase.rawQuery("SELECT * FROM countries", null);
        int nameIndex = cursor.getColumnIndex("name");
        int capIndex1 = cursor.getColumnIndex("capitalName");
        int flagIndex2 = cursor.getColumnIndex("flag");
        int nameIndex3 = cursor.getColumnIndex("primeMinisterName");
        int nameIndex4 = cursor.getColumnIndex("description");
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            String name = cursor.getString(nameIndex);
            int flag = Integer.parseInt(cursor.getString(flagIndex2));
            Log.i(TAG, "Name: " + name);
            String capitalName = cursor.getString(capIndex1);
            Log.i(TAG, "capitalName: " + capitalName);
            String primeMinisterNmae = cursor.getString(nameIndex3);
            Log.i(TAG, "primeMinisterNmae: " + primeMinisterNmae);
            String description = cursor.getString(nameIndex4);
            Log.i(TAG, "description: " + description);
            Country country = new Country(name, capitalName, flag, primeMinisterNmae, description);
            countries.add(country);
            cursor.moveToNext();
        }
        return countries;
    }

    public Country getCountry(int position) {
        Cursor cursor = myDatabase.rawQuery("SELECT * FROM countries where position = " +(position+1), null);
        int nameIndex = cursor.getColumnIndex("name");
        int capIndex1 = cursor.getColumnIndex("capitalName");
        int flagIndex2 = cursor.getColumnIndex("flag");
        int nameIndex3 = cursor.getColumnIndex("primeMinisterName");
        int nameIndex4 = cursor.getColumnIndex("description");
        cursor.moveToFirst();

            String name = cursor.getString(nameIndex);
            int flag = Integer.parseInt(cursor.getString(flagIndex2));
            String capitalName = cursor.getString(capIndex1);
            String primeMinisterNmae = cursor.getString(nameIndex3);
            String description = cursor.getString(nameIndex4);
            Country country = new Country(name, capitalName, flag, primeMinisterNmae, description);
           // countries.add(country);
            return country;
        }

        public void insertCountry (Country country){
           String insertQuery = "INSERT INTO countries(name,capitalName,flag,primeMinisterName,description) values" +
                   "('" +country.name+ "','" +country.capitalName+ "',"+R.drawable.india +",'" +country.primeMinisterName+ "','" +country.description+ "')";
            myDatabase.execSQL(insertQuery);
        }

        private boolean checkIfcountryTableIsEmpty(){
        Cursor cur = myDatabase.rawQuery("SELECT COUNT(*) FROM countries",null);
        if (cur != null){
            cur.moveToFirst();
            if (cur.getInt(0)==0){
                return true;
            }
        }
        return false;
        }
}

