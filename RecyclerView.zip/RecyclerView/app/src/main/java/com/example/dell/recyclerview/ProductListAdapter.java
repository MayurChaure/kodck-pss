package com.example.dell.recyclerview;

import android.annotation.SuppressLint;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.dell.recyclerview.ListViewHolder;
import com.example.dell.recyclerview.R;

import java.util.List;

public class ProductListAdapter extends RecyclerView.Adapter<ListViewHolder> {
  private static final String TAG = "ProductListAdapter";
 /* private List<String> values;
  private List<String> capital;
  private List<Integer> images;*/
 /* ProductListAdapter(List values, List capital,List images){
    this.values = values;
    this.capital = capital;
    this.images=images;
  }*/
 private ListViewHolder listViewHolder;
 private List<Country> countries;

 ProductListAdapter(List countries){
    this.countries=countries;

 }
    @Override
    public ListViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
      Log.d(TAG,"onCreateViewHolder:");
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.item,parent,false);
        ListViewHolder listViewHolder = new ListViewHolder(view);
        return listViewHolder;
    }
    @SuppressLint("LongLogTag")
    @Override
    public void onBindViewHolder(ListViewHolder holder, int position) {
     Log.d(TAG, " onBindViewHolder:");
    /* ListViewHolder.textView2.setText(values.get(position));
      ListViewHolder.textView3.setText(capital.get(position));
      ListViewHolder.imageView.setImageResource(images.get(position));*/
        holder.textView2.setText(countries.get(position).name);
        holder.textView3.setText(countries.get(position).capitalName);
        holder.textView4.setText(countries.get(position).description);
        holder.textView5.setText(countries.get(position).primeMinisterName);
        holder.imageView.setImageResource(countries.get(position).flag);
      }

    @Override
    public int getItemCount() {
    //return values.size();
      return countries.size();
    }
}
